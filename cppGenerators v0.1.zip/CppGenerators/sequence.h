#pragma once
#include <windows.h>
#include <functional>
#pragma warning (disable : 4127)
#include <pplawait.h>

template <typename T> class sequence_impl;

class __resumable_func_base
{
	__declspec(thread) static int ts_count;

protected:
	// Convert the thread to a fiber.
	static void ConvertCurrentThreadToFiber()
	{
		if (!IsThreadAFiber())
		{
			// Convert the thread to a fiber. Use FIBER_FLAG_FLOAT_SWITCH on x86.
			LPVOID threadFiber = ConvertThreadToFiberEx(nullptr, FIBER_FLAG_FLOAT_SWITCH);
			if (threadFiber == NULL)
			{
				throw std::bad_alloc();
			}
			ts_count = 1;
		}
		else
		{
			ts_count++;
		}
	}

	// Convert the fiber back to a thread.
	static void ConvertFiberBackToThread()
	{
		if (--ts_count == 0)
		{
			if (ConvertFiberToThread() == FALSE)
			{
				throw std::bad_alloc();
			}
		}
	}
};
__declspec(thread) int __resumable_func_base::ts_count = 0;

template <typename TRet>
class __resumable_func : __resumable_func_base
{
	typedef std::function<void(__resumable_func&)> TFunc;

	__resumable_func(const __resumable_func& rhs) = delete;
	__resumable_func(__resumable_func&& rhs) = delete;
	__resumable_func& operator = (const __resumable_func& rhs) = delete;
	__resumable_func& operator = (__resumable_func&& rhs) = delete;

public:
	Concurrency::details::__resumable_func_fiber_data*	_pFuncData;
	LPVOID _pCallerFiber;
	const TFunc _func;
	TRet _currentValue;
	LPVOID _pFiber;

	__resumable_func(const TFunc func) :
		_currentValue(TRet()),
		_pFiber(nullptr),
		_func(func)
	{
		// Convert the current thread to a fiber. This is needed because the thread needs to "be" a fiber in order
		// to be able to switch to another fiber.
		ConvertCurrentThreadToFiber();

		// Set up the initialization data and pass it to the other fiber.
		_pFuncData = nullptr;
		_pCallerFiber = GetCurrentFiber();

		// Create a new fiber (or re-use an existing one from the pool)
		_pFiber = Concurrency::details::POOL CreateFiberEx(Concurrency::details::fiberPool.commitSize,
			Concurrency::details::fiberPool.allocSize, FIBER_FLAG_FLOAT_SWITCH, &ResumableFuncFiberProc, this);
		if (!_pFiber) {
			throw std::bad_alloc();
		}

		// Switch to the newly created fiber. When this "returns" the functor has either returned, or issued an 'yield' statement.
		::SwitchToFiber(_pFiber);

		_pFuncData->suspending = false;
		_pFuncData->Release();
	}

	~__resumable_func()
	{
		if (_pCallerFiber != nullptr) {
			ConvertFiberBackToThread();
		}
	}

	void yieldReturn(TRet value)
	{
		_currentValue = value;
		yield();
	}

	void yieldBreak()
	{
		_pFiber = nullptr;
		yield();
	}

	const TRet& getCurrent() const {
		return _currentValue;
	}

	bool isEos() const {
		return _pFiber == nullptr;
	}

private:
	// Entry proc for the Resumable Function Fiber.
	static VOID CALLBACK ResumableFuncFiberProc(PVOID lpParameter)
	{
		LPVOID threadFiber;

		// This function does not formally return, due to the SwitchToFiber call at the bottom.
		// This scope block is needed for the destructors of the locals in this block to fire
		// before we do the SwitchToFiber.
		{
			Concurrency::details::__resumable_func_fiber_data funcDataOnFiberStack;
			__resumable_func* pThis = (__resumable_func*)lpParameter;

			// The callee needs to setup some more stuff after we return (which would be either on
			// yield or an ordinary return). Hence the callee needs the pointer to the func_data 
			// on our stack. This is not unsafe since the callee has a refcount on this structure
			// which means the fiber will continue to live.
			pThis->_pFuncData = &funcDataOnFiberStack;

			Concurrency::details::POOL SetFiberData(&funcDataOnFiberStack);

			funcDataOnFiberStack.threadFiber = pThis->_pCallerFiber;
			funcDataOnFiberStack.resumableFuncFiber = GetCurrentFiber();

			// Finally calls the function in the context of the fiber. The execution can be suspended
			// by calling yield
			pThis->_func(*pThis);

			// Here the function has completed. We set return to true meaning this is the final 'real'
			// return and not one of the 'yield' returns.
			funcDataOnFiberStack.returned = true;
			pThis->_pFiber = nullptr;
			threadFiber = funcDataOnFiberStack.threadFiber;
		}

		// Return to the calling fiber.
		::SwitchToFiber(threadFiber);

		// On a normal fiber this function won't exit after this point. However, if the fiber is in a fiber-pool 
		// and re-used we can get control back. So just exit this function, which will cause the fiber pool to spin around and re-enter.
	}

	static void yield()
	{
		_ASSERT(IsThreadAFiber());
		Concurrency::details::__resumable_func_fiber_data* funcDataOnFiberStack =
			Concurrency::details::__resumable_func_fiber_data::GetCurrentResumableFuncData();

		// Add-ref's the fiber. Even though there can only be one thread active in the fiber context, there
		// can be multiple threads accessing the fiber data.
		funcDataOnFiberStack->AddRef();

		_ASSERT(funcDataOnFiberStack);
		funcDataOnFiberStack->verify();

		// Mark as busy suspending. We cannot run the code in the 'then' statement 
		// concurrently with the await doing the setting up of the fiber.
		_ASSERT(!funcDataOnFiberStack->suspending);
		funcDataOnFiberStack->suspending = true;

		// Make note of the thread that we're being called from (Note that we'll always resume on the same thread).
		funcDataOnFiberStack->awaitingThreadId = GetCurrentThreadId();

		_ASSERT(funcDataOnFiberStack->resumableFuncFiber == GetCurrentFiber());

		// Return to the calling fiber.
		::SwitchToFiber(funcDataOnFiberStack->threadFiber);
	}

public:
	void resume()
	{
		_ASSERT(IsThreadAFiber());
		_ASSERT(_pFiber != nullptr);
		_ASSERT(_pFuncData != nullptr);
		_ASSERT(!_pFuncData->suspending);
		_ASSERT(_pFuncData->awaitingThreadId == (int)GetCurrentThreadId());

		// Switch to the fiber. When this "returns" the functor has either returned, or issued an 'yield' statement.
		::SwitchToFiber(_pFiber);

		_ASSERT(_pFuncData->returned || _pFuncData->suspending);
		_pFuncData->suspending = false;
		if (_pFuncData->returned) {
			_pFiber = nullptr;
		}
		_pFuncData->Release();
	}
};

template <typename T>
class sequence_iterator
{
	friend class sequence_impl<T>;
	std::unique_ptr<__resumable_func<T>> _resumableFunc;

	sequence_iterator() :
		_resumableFunc(nullptr)
	{
	}

	sequence_iterator(const std::function<void(__resumable_func<T>&)> func) :
		_resumableFunc(new __resumable_func<T>(func))
	{
	}

	sequence_iterator(const sequence_iterator& rhs) = delete;
	sequence_iterator& operator = (const sequence_iterator& rhs) = delete;
	sequence_iterator& operator = (sequence_iterator&& rhs) = delete;

public:
	sequence_iterator(sequence_iterator&& rhs) :
		_resumableFunc(std::move(rhs._resumableFunc))
	{
	}

	sequence_iterator& operator++()
	{
		_ASSERT(_resumableFunc != nullptr);
		_resumableFunc->resume();
		return *this;
	}

	bool operator==(const sequence_iterator& _Right) const
	{
		if (_resumableFunc == _Right._resumableFunc) {
			return true;
		}

		if (_resumableFunc == nullptr) {
			return _Right._resumableFunc->isEos();
		}

		if (_Right._resumableFunc == nullptr) {
			return _resumableFunc->isEos();
		}

		return (_resumableFunc->isEos() == _Right._resumableFunc->isEos());
	}

	bool operator!=(const sequence_iterator& _Right) const
	{
		return (!(*this == _Right));
	}

	const T& operator*() const
	{
		_ASSERT(_resumableFunc != nullptr);
		return (_resumableFunc->getCurrent());
	}
};

template <typename T>
class sequence_impl
{
public:
	typedef std::function<void(__resumable_func<T>&)> functor;

private:
	const functor _func;

	sequence_impl(const sequence_impl& rhs) = delete;
	sequence_impl(sequence_impl&& rhs) = delete;
	sequence_impl& operator = (const sequence_impl& rhs) = delete;
	sequence_impl& operator = (sequence_impl&& rhs) = delete;

public:
	sequence_impl(const functor func) : _func(std::move(func)) {
	}

	// code review: const???
	sequence_iterator<T> begin() const
	{
		// return iterator for beginning of sequence
		return sequence_iterator<T>(_func);
	}
	sequence_iterator<T> end() const
	{
		// return iterator for end of sequence
		return sequence_iterator<T>();
	}
};

template <typename T>
class sequence
{
	std::shared_ptr<sequence_impl<T>> _impl;

	sequence(const sequence& rhs) = delete;
	sequence& operator = (const sequence& rhs) = delete;

public:
	typedef typename sequence_iterator<T> iterator;
	typedef typename sequence_impl<T>::functor functor;

	sequence(functor func) :
		_impl(std::make_shared<sequence_impl<T>>(func))
	{
	}
	sequence(sequence&& rhs) {
		_impl = std::move(rhs._impl);
	}
	sequence& operator = (sequence&& rhs) {
		_impl = std::move(rhs._impl);
	}

	iterator begin() const {
		return _impl->begin();
	}
	iterator end() const {
		return _impl->end();
	}

	////////////////////////////////////////////////////////////////////////////
	// All

	// Determines whether all elements of a sequence satisfy a condition.
	bool all(std::function<bool(T)> predicate)
	{
		if (nullptr == predicate) {
			throw std::exception();
		}

		for (auto t : *_impl)
		{
			if (!predicate(t)) {
				return false;
			}
		}
		return true;
	}

	////////////////////////////////////////////////////////////////////////////
	// Empty
	static sequence<T> empty()
	{
		// deferred
		auto fn = [](__resumable_func<T>& rf) {
			rf.yieldBreak();
		};
		return sequence<T>(fn);
	}

	////////////////////////////////////////////////////////////////////////////
	// Range

	// Generates a sequence of integral numbers within a specified range [from, to).
	static sequence<int> range(int from, int to)
	{
		if (to < from) {
			throw std::exception();
		}

		// deferred
		auto fn = [from, to](__resumable_func<T>& rf) {
			for (int i = from; i < to; i++) {
				rf.yieldReturn(i);
			}
		};
		return sequence<int>(fn);
	}


	///////////////////////////////////////////////////////////////////////////
	// Select

	// Projects each element of a sequence into a new form.
	template <typename TResult>
	sequence<TResult> select(std::function<TResult(T)> selector) {
		if (nullptr == selector) {
			throw std::exception();
		}

		// deferred
		std::shared_ptr<sequence_impl<T>> impl = _impl;
		auto fn = [impl, selector](__resumable_func<T>& rf) {
			for (auto t : *impl)
			{
				auto val = selector(t);
				rf.yieldReturn(val);
			}
		};
		return sequence<TResult>(fn);
	}

	////////////////////////////////////////////////////////////////////////////
	// Take

	// Returns a specified number of contiguous elements from the start of a sequence.
	sequence<T> take(int count)
	{
		if (count < 0) {
			throw std::exception();
		}

		// deferred
		std::shared_ptr<sequence_impl<T>> impl = _impl;
		auto fn = [impl, count](__resumable_func<T>& rf) {
			auto it = impl->begin();
			for (int i = 0; i < count && it != impl->end(); i++, ++it) {
				rf.yieldReturn(*it);
			}
		};
		return sequence<T>(fn);
	}

	///////////////////////////////////////////////////////////////////////////
	// Where

	// Filters a sequence of values based on a predicate.
	sequence<T> where(std::function<bool(T)> predicate)
	{
		if (nullptr == predicate) {
			throw std::exception();
		}

		// deferred
		std::shared_ptr<sequence_impl<T>> impl = _impl;
		auto fn = [impl, predicate](__resumable_func<T>& rf) {
			for (auto item : *impl)
			{
				if (predicate(item)) {
					rf.yieldReturn(item);
				}
			}
		};
		return sequence<T>(fn);
	}
	sequence<T> whereIndex(std::function<bool(T, int)> predicate)
	{
		if (nullptr == predicate) {
			throw std::exception();
		}

		// deferred
		std::shared_ptr<sequence_impl<T>> impl = _impl;
		auto fn = [impl, predicate](__resumable_func<T>& rf) {
			int index = 0;
			for (auto item : *impl)
			{
				if (predicate(item, index)) {
					rf.yieldReturn(item);
				}
				index++;
			};
		};
		return sequence<T>(fn);
	}
};