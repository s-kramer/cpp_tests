#include <windows.h>
#include <iostream>
#include <memory>
#include <math.h>
#include "sequence.h"

sequence<long> fibonacci()
{
	auto fibs = [](__resumable_func<long>& it) {
		long a = 0;
		long b = 1;
		it.yieldReturn(b);
		while (true) {
			long tmp = a + b;
			a = b;
			b = tmp;
			it.yieldReturn(b);
		}
	};
	return sequence<long>(fibs);
}

void testFibonacci(int max)
{
	std::cout << "Fibonacci" << std::endl;
	for (auto n : fibonacci())
	{
		if (n > max) {
			break;
		}
		std::cout << n << std::endl;
	}
	std::cout << std::endl;
}

sequence<int> primes(int max)
{
	return sequence<int>::range(2, max)
		.where([](int i) {
			return sequence<int>::range(2, (int)sqrt(i) + 2)
				.all([i](int j) { return (i % j) != 0; });
		});
}

void testPrimes(int max)
{
	std::cout << "Prime numbers" << std::endl;
	for (auto p : primes(max))
	{
		std::cout << p << std::endl;
	}
	std::cout << std::endl;
}

sequence<std::tuple<int, int, int>> ntriples()
{
	// Finds the first N Pythagorean triples:
	//
	//main = print(take 10 triples)
	//triples = do
	//	z <-[1..]
	//	x <-[1..z]
	//	y <-[x..z]
	//	guard(x ^ 2 + y ^ 2 == z ^ 2)
	//	return (x, y, z)

	auto lambda = [](__resumable_func<std::tuple<int, int, int>>& it) {
		for (auto z : sequence<int>::range(1, 10000))
		{
			for (auto x : sequence<int>::range(1, z))
			{
				for (auto y : sequence<int>::range(x, z))
				{
					if (x*x + y*y == z*z)
					{
						it.yieldReturn(std::tuple<int, int, int>(x, y, z));
					}
				}
			}
		}
	};
	return sequence<std::tuple<int, int, int>>(lambda);
}

void testNTriples(int max)
{
	std::cout << "Pythagorean triples" << std::endl;
	for (auto triple : ntriples().take(max))
	{
		std::cout << std::get<0>(triple) << ", " <<
			std::get<1>(triple) << ", " <<
			std::get<2>(triple) << std::endl;
	}
	std::cout << std::endl;
}

int main(int /*argc*/, wchar_t* /*argv[]*/)
{
	testFibonacci(100);
	testPrimes(100);
	testNTriples(10);

	return 0;
}

