template <class Operacja, class T>
	binder1st<Operacja> bind1st (const Operacja& op, const T& x);
