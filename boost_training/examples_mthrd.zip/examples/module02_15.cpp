virtual void setLayout(const LayoutPtr & layout);
