virtual void addAppender(const AppenderPtr & newAppender);
