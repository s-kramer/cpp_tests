template <class Operacja, class T>
	binder2nd<Operacja> bind2nd (const Operacja& op, const T& x);
