void log(const LevelPtr & level, const std::string & message) const;
