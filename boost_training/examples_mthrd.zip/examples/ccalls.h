#ifdef __cplusplus
extern "C" {
#endif
/*
 * Tre�� w�asnego nag��wka biblioteki C 
 */
#ifdef __cplusplus
}
#endif
