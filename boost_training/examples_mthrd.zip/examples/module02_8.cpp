void forcedLog(const LevelPtr & level, const std::wstring & message) const;
