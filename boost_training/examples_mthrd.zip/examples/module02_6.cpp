void trace(const std::string & msg) const;
