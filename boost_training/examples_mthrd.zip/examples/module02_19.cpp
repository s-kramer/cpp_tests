log4cxx::LoggerPtr logger(log4cxx::Logger::getLogger("log.config");
