template <class Arg, class Rezultat>
	struct unary_function {
		typedef Arg argument_type;
		typedef Result result_type;
	};
