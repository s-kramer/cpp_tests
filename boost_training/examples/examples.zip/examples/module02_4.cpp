std::streambuf * rdbuf() const;
std::streambuf * rdbuf(std::streambuf *);
