extern "C" {
	void function(int, double, char *);
	void exec_data(void);
	char * alter_string(char*);
}
