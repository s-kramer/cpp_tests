static void PropertyConfigurator::configure (const File & configFilename);
