extern "C" {
	// Wczytanie nag��wka dla j�zyka C
	#include <naglowek_z_c.h>
}
