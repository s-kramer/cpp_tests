virtual void setLevel(const LevelPtr & level);
