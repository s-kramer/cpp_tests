void l7dlog(const LevelPtr & level, const std::string & key, 
				const log4cxx::spi::LocationInfo & locationInfo) const;
