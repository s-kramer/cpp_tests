void setAdditivity(bool additive);
