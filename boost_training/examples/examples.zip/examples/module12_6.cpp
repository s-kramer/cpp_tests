boost::regex e(my_regex, boost::regex::perl | boost::regex::icase);
